import java.awt.*;

public class PanelDeImagen {
    public static void main(String[] args) {
        // ImagenOF imagen = AdministradorDeArchivos.getImagen();
    }

    public void setImagen(ImagenOF imagen) {
    }
}
