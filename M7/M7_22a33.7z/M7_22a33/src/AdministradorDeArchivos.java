import java.awt.*;

public class AdministradorDeArchivos {

    /*
    public static ImagenOF getImagen() {
        // ImagenOF imgOF = new ImagenOF();
        return new ImagenOF();
    }
     */

}
