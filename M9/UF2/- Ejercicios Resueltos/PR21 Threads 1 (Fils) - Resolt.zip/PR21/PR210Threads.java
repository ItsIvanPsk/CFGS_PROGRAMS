public class PR210Threads implements Runnable {

    private boolean running = true;

    public static void main (String[] args) {

        PR210Threads P0 = new PR210Threads();
        PR210Threads P1 = new PR210Threads();
        PR210Threads P2 = new PR210Threads();
        PR210Threads P3 = new PR210Threads();

        Thread T0 = new Thread(P0, "T0");
        Thread T1 = new Thread(P1, "T1");
        Thread T2 = new Thread(P2, "T2");
        Thread T3 = new Thread(P3, "T3");
        
        T0.start();
        T1.start();
        T2.start();
        T3.start();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e1) { e1.printStackTrace(); }

        try {
            P0.stop();
            P1.stop();
            P2.stop();
            P3.stop();

            T0.join();
            T1.join();
            T2.join();
            T3.join();
        } catch (Exception e) {}
    }

    public void stop () {
        this.running = false;
    }

    @Override
    public synchronized void run() {
        running = true;
        while(running) {
            System.out.println("Hola Món " + Thread.currentThread().getName());
            try {
                wait(10);
            } catch (InterruptedException e) { e.printStackTrace(); }
        }
    }
}