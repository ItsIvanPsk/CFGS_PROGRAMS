import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

public class PR212Threads implements Runnable {

    public static void main(String[] args) {

        Thread ths = new Thread(new PR212Threads());
        ths.setDaemon(false);
        ths.start();
        System.out.println("Programa acabat");     
    }

    public void run () {
        String arxiu = "ordenat.txt";
        
        File f = new File("./" + arxiu);
        f.delete();

        try {
            System.out.println("Ordenant ...");  
            String line;
            ProcessBuilder pb = new ProcessBuilder("sort", "-n", "-o" + arxiu, "llista.txt");
            Process p = pb.start();
            BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
            while ((line = input.readLine()) != null) {
                System.out.println(line);
            }
            input.close();
            System.out.println("Ordenació acabada");  
 
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
