public class PR211Threads implements Runnable {

    static int compartit = 0;
    int contador = 0;

    public static void main (String[] args) {

        Thread T0 = new Thread(new PR211Threads(), "T0");
        Thread T1 = new Thread(new PR211Threads(), "T1");
        Thread T2 = new Thread(new PR211Threads(), "T2");
        Thread T3 = new Thread(new PR211Threads(), "T3");
        
        T0.start();
        T1.start();
        T2.start();
        T3.start();

        try {
            T0.join();
            T1.join();
            T2.join();
            T3.join();
        } catch (Exception e) {}

        System.out.println(PR211Threads.compartit);
    }

    @Override
    public synchronized void run() {
        while(contador < 5000) {
            PR211Threads.compartit = PR211Threads.compartit + 1;
            contador = contador + 1;
        }
    }
}