public class Treballador {
    private int ID;
    private String name;
    private String sur_name;
    private int Dept;
    private float salary;

    public Treballador(int ID, String name, String sur_name, int dept, float salary) {
        this.ID = ID;
        this.name = name;
        this.sur_name = sur_name;
        Dept = dept;
        this.salary = salary;
    }
}

